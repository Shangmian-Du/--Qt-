#include "widget.h"
#include "ui_widget.h"
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <QTextStream>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    this->setWindowTitle("蒙特卡洛作业1_计算器");
    QFont f("仿宋",20);
    ui->mainLineEdit->setFont(f);

    //改变按钮背景色
    //ui->pushButton_equal->setStyleSheet("background::blue");
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_1_clicked()
{
    expression += "1";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_2_clicked()
{
    expression += "2";
    ui->mainLineEdit->setText(expression);
}



void Widget::on_pushButton_3_clicked()
{
    expression += "3";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_4_clicked()
{
    expression += "4";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_5_clicked()
{
    expression += "5";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_6_clicked()
{
    expression += "6";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_7_clicked()
{
    expression += "7";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_8_clicked()
{
    expression += "8";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_9_clicked()
{
    expression += "9";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_0_clicked()
{
    expression += "0";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_point_clicked()
{
    expression += ".";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_percentage_clicked()
{
    expression += "%";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_add_clicked()
{
    expression += "+";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_sub_clicked()
{
    expression += "-";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_multi_clicked()
{
    expression += "×";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_devide_clicked()
{
    expression += "÷";
    ui->mainLineEdit->setText(expression);
}


void Widget::on_pushButton_equal_clicked()
{
    class Calculator {
    public:
        double calculate(const QString& expression) {
            QStack<double> numbers;
            QStack<char> operators;
            QByteArray byteArray = expression.toUtf8(); // 转换为 QByteArray
            QTextStream ss(&byteArray); // 使用 QTextStream 来读取 QByteArray
            double number;
            char op;

            // 读取表达式中的数字和操作符
            while (!ss.atEnd()) {
                ss >> number;
                numbers.push(number);

                if (!ss.atEnd()) {
                    ss >> op;
                    while (!operators.empty() && getPriority(operators.top()) >= getPriority(op)) {
                        double b = numbers.top(); numbers.pop();
                        double a = numbers.top(); numbers.pop();
                        char topOp = operators.top(); operators.pop();
                        numbers.push(operate(b, a, topOp));
                    }
                    operators.push(op);
                }
            }

            while (!operators.empty()) {
                double b = numbers.top(); numbers.pop();
                double a = numbers.top(); numbers.pop();
                char topOp = operators.top(); operators.pop();
                numbers.push(operate(b, a, topOp));
            }

            return numbers.top();
        }

    private:
        int getPriority(char op) {
            if (op == '+' || op == '-') return 1;
            if (op == '*' || op == '/') return 2;
            return 0;
        }

        double operate(double b, double a, char op) {
            if (op == '+') return a + b;
            if (op == '-') return a - b;
            if (op == '*') return a * b;
            if (op == '/') return a / b;
            return 0;
        }
    };

    // 直接使用成员变量 expression，而不是重新定义
    Calculator calc;

    // 获取用户输入的表达式
    QString expr = expression;

    // 将运算符从中文符号转为英文符号
    expr.replace("×", "*");
    expr.replace("÷", "/");

    // 计算表达式的结果
    double result = calc.calculate(expr);

    // 在 UI 上显示结果
    ui->mainLineEdit->setText(QString::number(result));
}



void Widget::on_pushButton_clean_clicked()
{
    expression.clear();
    ui->mainLineEdit->clear();
}


void Widget::on_pushButton_back_clicked()
{
    expression.chop(1);
    ui->mainLineEdit->setText(expression);
}

